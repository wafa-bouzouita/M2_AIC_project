This directory contains the directory 'full_data' which contains all the pre-processed data for the Plankton challenge : train set, valid set, test set and their ground truth.

This is for use with Codalab and Chalab.

Team GAIASAVERS -- 2019-2020

References and credits: 
K. Cheng. Bering sea dataset. https://doi.org/10.6084/m9.figshare.8146283.v3, 2019.