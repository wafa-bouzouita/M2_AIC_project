This directory contains a make file to create a challenge bundle.

Usage (1) with sample data only:
	`python make_bundle.py`
	
Usage (2) with big data:
	`python make_bundle.py ../ ../../FILES/iris`
	
Change the name "iris"  to the name of your dataset.